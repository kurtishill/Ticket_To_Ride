package com.example.server.Commands;

/**
 * Created by ckingsbu on 1/29/18.
 */

public interface Command {
    void execute();
}
