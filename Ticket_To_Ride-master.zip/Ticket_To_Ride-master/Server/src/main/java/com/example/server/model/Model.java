package com.example.server.model;

import java.util.List;
import java.util.Map;

/**
 * Created by ckingsbu on 1/29/18.
 */

public class Model {
    private static Model instance = null;
    protected Model(){}
    public static Model getInstance() {
        if(instance == null) {
            instance = new Model();
        }
        return instance;
    }
    private List<User> userList;
    private Map<String, User> userMap;
    public String AddUser(String username, String password){
        User newUser = new User(username, password);
        userList.add(newUser);
        userMap.put(newUser.getAuthToken(), newUser);
        return newUser.getAuthToken();
    }
    public boolean UserExists(String username){
        for(int i = 0; i < userList.size(); i ++){
            if(userList.get(i).equals(username)){
                return true;
            }
        }
        return false;
    }
    public String Login(String username){return null;}

}
