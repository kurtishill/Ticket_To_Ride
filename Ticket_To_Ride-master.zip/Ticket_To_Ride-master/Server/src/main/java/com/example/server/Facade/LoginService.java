package com.example.server.Facade;

import com.example.server.model.Model;

/**
 * Created by ckingsbu on 1/29/18.
 */

public class LoginService {
    @SuppressWarnings("serial")
    public static class UserExistsException extends Exception {
        public UserExistsException(){
            System.out.println("Users Exists");
        }
    }
    public void Login(String username, String password) throws UserExistsException{
        if(Model.getInstance().UserExcists(username)){
            Model.getInstance().AddUser(username, password);
        }
        else {
            throw new UserExistsException();
        }
    }
}
