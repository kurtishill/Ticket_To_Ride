package com.example.server.model;

import java.util.UUID;

/**
 * Created by ckingsbu on 1/29/18.
 */

public class User {
    private String username;
    private String password;
    private String authToken;
    public User(String username, String password){
        this.password = password;
        this.username = username;
        authToken = UUID.randomUUID().toString();
    }

    public String getAuthToken() {
        return authToken;
    }
}
