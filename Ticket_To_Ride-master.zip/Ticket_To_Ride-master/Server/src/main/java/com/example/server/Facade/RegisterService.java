package com.example.server.Facade;

import com.example.server.model.Model;

/**
 * Created by ckingsbu on 1/29/18.
 */

public class RegisterService {
    @SuppressWarnings("serial")
    public static class UserExistsException extends Exception {
        public UserExistsException(){
            System.out.println("Users Exists");
        }
    }
    public String Register(String username, String password) throws UserExistsException {
        if(!Model.getInstance().UserExcists(username)){
            return Model.getInstance().AddUser(username, password);
        }
        else {
            throw new UserExistsException(); // might want to just return null instead..
        }
    }
}
