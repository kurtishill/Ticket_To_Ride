package com.example.hillcollegemac.tickettoride;

import java.util.Observable;
import java.util.Observer;

/**
 * Created by HillcollegeMac on 1/29/18.
 */

public class GameWaitingLobbyPresenter implements IGameWaitingLobbyPresenter, Observer {

    public void joinGame(/*Game object*/) {

    }

    public void update(Observable obs, Object obj) {

    }
}
